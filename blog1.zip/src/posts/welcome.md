---
title: Welcome to the Triple Action Blog
layout: layouts/base.njk
tags: post
---

This is your first post. Edit it in `src/posts/welcome.md`. Add more posts by creating more markdown files in `src/posts`.

# TripleAction Blog Starter (Eleventy)

**Deploy on Netlify** in minutes.

## Quickstart
```bash
npm install
npm run dev   # local preview
npm run build # generates _site for Netlify
```

- Posts live in `src/posts` as Markdown (`.md`).
- Edit nav and layout in `src/_includes/layouts/base.njk`.
- Netlify will run `npm run build` and publish `_site`.
